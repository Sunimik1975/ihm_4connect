// mainwindow.cpp

#include "mainwindow.h"
#include "gameboard.h"
#include "ui_mainwindow.h"
#include "RegisterWindow.h"
#include "Connect4.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow) {
    ui->setupUi(this);

    // Conectar el botón "Registrar jugador" a la función para abrir RegisterWindow
    connect(ui->registerButtonM, &QPushButton::clicked, this, &MainWindow::openRegisterWindow);
    connect(ui->loginButton, &QPushButton::clicked, this, &MainWindow::login);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::openRegisterWindow() {
    RegisterWindow* registerWindow = new RegisterWindow();

    // Conectar la señal de RegisterWindow a la función que maneja el registro de jugadores en Connect4
    bool connected = connect(registerWindow, &RegisterWindow::registerPlayer, this, [=](const QString& nickName, const QString& email,
                                                                                        const QString& password, const QDate& birthdate,
                                                                                        int points, const QImage& avatar) {
        Player* player = Connect4::getInstance().registerPlayer(nickName, email, password, birthdate, points);

        if (player) {
            QMessageBox::information(this, "Éxito", "Jugador registrado exitosamente.");
        } else {
            QMessageBox::critical(this, "Error", "No se pudo registrar el jugador.");
        }
    });

    // Mostrar la ventana de registro
    registerWindow->show();
}

void MainWindow::login() {
    QString nickName = ui->nicknameLineEditM->text();
    QString passwordM = ui->passwordLineEditM->text();

    // Verificar si el jugador ya está activo en el juego
    if (activePlayers.contains(nickName)) {
        QMessageBox::warning(this, "Jugador Activo", "Este jugador ya está en una partida.");
        return;
    }

    // Validar datos
    Player* player = Connect4::getInstance().loginPlayer(nickName, passwordM);
    if (player) {
        // Informar al usuario que el inicio de sesión fue exitoso
        QMessageBox::information(this, "Éxito", QString("%1 ha iniciado sesión.").arg(nickName));

        // Agregar el jugador a la lista de jugadores activos
        activePlayers.append(nickName);

        // Si ya hay 2 jugadores activos, comenzar la partida
        if (activePlayers.size() >= 2) {
            QString player1 = activePlayers.at(0);
            QString player2 = activePlayers.at(1);

            // Verifica si ya hay una partida en curso
            if (!gameBoard) {
                // Crear y mostrar la ventana del tablero de juego solo si no existe una instancia
                gameBoard = new GameBoard(player1, player2);
                gameBoard->show();
            }

            // Cerrar la ventana principal
            this->close();
        }
    } else {
        // Si el login falla, mostrar un mensaje de error
        QMessageBox::critical(this, "Error", "Nombre de usuario o contraseña incorrectos.");
    }

    // Borrar el contenido de los campos de texto
    ui->nicknameLineEditM->clear();
    ui->passwordLineEditM->clear();
}

