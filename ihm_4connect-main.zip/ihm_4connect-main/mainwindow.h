// mainwindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include "gameboard.h"  // Asegúrate de incluir el archivo de GameBoard

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void openRegisterWindow();
    void login();

private:
    Ui::MainWindow *ui;
    QList<QString> activePlayers;  // Lista de jugadores activos
    GameBoard* gameBoard = nullptr;  // Puntero a la instancia de GameBoard, inicializado como nullptr
};

#endif // MAINWINDOW_H
